package com.highradius.implementation;

public class InvoiceDao {

}
