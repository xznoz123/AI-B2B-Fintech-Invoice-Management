package com.highradius.implementation;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servletdata")
public class ServletData extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Forward the GET request to the doPost method
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrc", "root", "Ashish@009");
            System.out.println("Connection is created successfully:");

            String customerOrderId = request.getParameter("CUSTOMER_ORDER_ID"); // Get the customer ID parameter

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM h2h_oap WHERE CUSTOMER_ORDER_ID = ?");
            ps.setString(1, customerOrderId);
            ResultSet rs = ps.executeQuery();

            PrintWriter out = response.getWriter();

            out.println("<html><head>");
            out.println("<style>");
            out.println("body { background-color: white; }");
            out.println("h1 { text-align: center; font-weight: bold; }");
            out.println("table { margin: 20px auto; border-collapse: collapse; width: 80%; }");
            out.println("th, td { padding: 10px; text-align: left; border: 2px solid #000000; }");
            out.println("th { background-color: #f2f2f2; }");
            out.println("tr:nth-child(odd) { background-color: #f9f9f9; }");
            out.println("tr:nth-child(even) { background-color: #ddd; }");
            out.println("th { background-color: lightgreen; }");
            out.println("</style>");
            out.println("</head><body>");

            out.println("<h1>Customer Order Details</h1>");
            out.println("<table>");
            out.println("<tr><th>Sl_no</th><th>CUSTOMER_ORDER_ID</th><th>SALES_ORG</th><th>AMOUNT_IN_USD</th><th>DISTRIBUTION_CHANNEL</th><th>COMPANY_CODE</th><th>ORDER_CREATION_DATE</th><th>ORDER_AMOUNT</th><th>ORDER_CURRENCY</th><th>CUSTOMER_NUMBER</th></tr>");

            int rowCount = 0;

            while (rs.next() && rowCount < 8) {
                int sl_no = rs.getInt("sl_no");
                int salesOrg = rs.getInt("SALES_ORG");
                double amountInUSD = rs.getDouble("AMOUNT_IN_USD");
                String distributionChannel = rs.getString("DISTRIBUTION_CHANNEL");
                int companyCode = rs.getInt("COMPANY_CODE");
                String orderCreationDate = rs.getString("ORDER_CREATION_DATE");
                double orderAmount = rs.getDouble("ORDER_AMOUNT");
                String orderCurrency = rs.getString("ORDER_CURRENCY");
                int customerNumber = rs.getInt("CUSTOMER_NUMBER");

                out.println("<tr><td>" + sl_no + "</td><td>" + customerOrderId + "</td><td>" + salesOrg + "</td><td>"
                        + amountInUSD + "</td><td>" + distributionChannel + "</td><td>" + companyCode + "</td><td>"
                        + orderCreationDate + "</td><td>" + orderAmount + "</td><td>" + orderCurrency + "</td><td>"
                        + customerNumber + "</td></tr>");

                rowCount++;
            }

            out.println("</table>");

            if (rowCount == 0) {
                out.println("<p>No data found for customer ID: " + customerOrderId + "</p>");
            } else if (rowCount >= 8) {
                out.println("<p>Showing first 8 rows. There may be more results.</p>");
            }

            out.println("</body></html>");

        } catch (ClassNotFoundException e1) {
            System.out.println("Driver not found: " + e1.getMessage());
        } catch (SQLException e1) {
            System.out.println("Database error: " + e1.getMessage());
        }
    }
}

