package com.highradius.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.highradius.model.Invoice;

public class Databaseconnection {
	private String jdbcurl="jdbc:mysql://localhost:3306/hrc= false";
	private String jdbcusername="root";
	private String jdbcpassword="Ashish@009";
	private String jdbcDriver="com.mysql.cj.jdbc.Driver";
	
	private static final String SELECT_USER_BY_ID="select sl_no,CUSTOMER_ORDER_ID ,SALES_ORG,AMOUNT_IN_USD,DISTRIBUTION_CHANNEL,COMPANY_CODE,ORDER_CREATION_DATE,ORDER_AMOUNT,ORDER_CURRENCY,CUSTOMER_NUMBER from users where id=?";
	
	public Databaseconnection() {
		
	}
	protected Connection getConnection() {
		
		Connection conn = null;
		 try {
			 
	         Class.forName("com.mysql.cj.jdbc.Driver");
	         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrc", "root", "Ashish@009");
	         System.out.println("Connection is created successfully:");
	         } catch (ClassNotFoundException e1) {
	             System.out.println("Driver not found: " + e1.getMessage());
	         } catch (SQLException e1) {
	             System.out.println("Database error: " + e1.getMessage());
	         } finally {
	             try {
	                 if (conn != null) {
	                     conn.close();
	                 }
	             } catch (SQLException e) {
	                 System.out.println("Failed to close connection: " + e.getMessage());
	             }
	}
		return conn;
	}
    
// select user by id
public int selectUser(int id) throws Exception {
	Invoice user=null;
	try(Connection connection= getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_USER_BY_ID);){
		
	}
	return id;
	
}}
