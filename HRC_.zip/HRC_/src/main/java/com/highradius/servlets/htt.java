package com.highradius.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/htt")
public class htt extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            response.setContentType("text/html");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrc", "root", "Ashish@009");
            System.out.println("Connection is created successfully:");

            // Pagination
            int start = 0;
            int recordsPerPage = 8;
            if (request.getParameter("start") != null) {
                start = Integer.parseInt(request.getParameter("start"));
            }

            PreparedStatement countPs = conn.prepareStatement("SELECT COUNT(*) FROM h2h_oap");
            ResultSet countRs = countPs.executeQuery();
            countRs.next();
            int totalRecords = countRs.getInt(1);

            int totalPages = (int) Math.ceil((double) totalRecords / recordsPerPage);

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM h2h_oap LIMIT ?, ?");
            ps.setInt(1, start);
            ps.setInt(2, Math.min(recordsPerPage, 1000 - start)); // Limit to remaining records if less than recordsPerPage
            ResultSet rs = ps.executeQuery();

            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<form action='edit' method='post'>"); // Add form for editing

            out.println("<table>");
            out.println("<tr><th></th><th>Sl_no</th><th>CUSTOMER_ORDER_ID</th><th>SALES_ORG</th><th>AMOUNT_IN_USD</th><th>DISTRIBUTION_CHANNEL</th><th>COMPANY_CODE</th><th>ORDER_CREATION_DATE</th><th>ORDER_AMOUNT</th><th>ORDER_CURRENCY</th><th>CUSTOMER_NUMBER</th></tr>");

            boolean hasNext = false;
            while (rs.next()) {
                int sl_no = rs.getInt("sl_no");
                int customerOrderId = rs.getInt("CUSTOMER_ORDER_ID");
                int salesOrg = rs.getInt("SALES_ORG");
                double amountInUSD = rs.getDouble("AMOUNT_IN_USD");
                String distributionChannel = rs.getString("DISTRIBUTION_CHANNEL");
                int companyCode = rs.getInt("COMPANY_CODE");
                String orderCreationDate = rs.getString("ORDER_CREATION_DATE");
                double orderAmount = rs.getDouble("ORDER_AMOUNT");
                String orderCurrency = rs.getString("ORDER_CURRENCY");
                int customerNumber = rs.getInt("CUSTOMER_NUMBER");

                out.println("<tr><td><input type='checkbox' name='selectedRow' value='" + sl_no + "'></td><td>" + sl_no + "</td><td>" + customerOrderId + "</td><td>" + salesOrg + "</td><td>" + amountInUSD + "</td><td>" + distributionChannel + "</td><td>" + companyCode + "</td><td>" + orderCreationDate + "</td><td>" + orderAmount + "</td><td>" + orderCurrency + "</td><td>" + customerNumber + "</td></tr>");

                hasNext = true;
            }

            out.println("</table>");

            // Next button
            if (hasNext) {
                int nextPage = start + recordsPerPage;
                out.println("<a href='htt?start=" + nextPage + "'>Next</a>");
            }

            // Displaying number of data and number of pages
            out.println("<br/>");
            out.println("Total Data: " + totalRecords);
            out.println("<br/>");
            out.println("Total Pages: " + totalPages);

            // Edit button
            out.println("<br/>");
            out.println("<input type='submit' value='Edit'>");

            out.println("</form>"); // Close form

            out.println("</body></html>");

            conn.close();
        } catch (ClassNotFoundException e1) {
            System.out.println("Driver not found: " + e1.getMessage());
        } catch (SQLException e1) {
            System.out.println("Database error: " + e1.getMessage());
        }
    }
}

